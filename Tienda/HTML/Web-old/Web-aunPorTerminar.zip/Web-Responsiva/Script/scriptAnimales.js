
function mover() {
        document.getElementById('rueda').classList.toggle('alt');
        document.getElementById('contenedorColorYRueda').classList.toggle('coloresAlt');
}
function cambiarColor(color) {
        var root = document.querySelector(':root');

        switch (color) {
                case 'azul':
                        root.style.setProperty('--color-primario', 'blue');
                        root.style.setProperty('--color-secundario', 'lightblue');
                        console.log("hola");
                        break;
                case 'rojo':
                        root.style.setProperty('--color-primario', 'red');
                        root.style.setProperty('--color-secundario', 'lightcoral');
                        break;
                case 'verde':
                        root.style.setProperty('--color-primario', 'green');
                        root.style.setProperty('--color-secundario', 'lightgreen');
                        break;
                case 'morado':
                        root.style.setProperty('--color-primario', 'purple');
                        root.style.setProperty('--color-secundario', 'lightpink');
                        break;
                case 'naranja':
                        root.style.setProperty('--color-primario', 'orange');
                        root.style.setProperty('--color-secundario', 'lightsalmon');
                        break;

                default:
                        break;
        }
}
function cambiaFrame(id) {
        var elemento1 = document.getElementById("primerCuadro");
        var elemento2 = document.getElementById('segundoCuadro');
        var elemento3 = document.getElementById('tercerCuadro');
        switch (id) {
                case '1':
                        document.getElementById('triangulo').classList.add('pos1');
                        document.getElementById('triangulo').classList.remove('pos3');
                        document.getElementById('triangulo').classList.remove('pos2');

                        document.getElementById('botonClinica').classList.add("botonActivo");
                        document.getElementById('botonFilosofia').classList.remove("botonActivo");
                        document.getElementById('botonEquipo').classList.remove("botonActivo");

                        elemento1.classList.add("activo");
                        elemento1.classList.remove('NoActivo');

                        elemento2.classList.remove('activo');
                        elemento3.classList.remove('activo');
                        elemento2.classList.add('NoActivo');
                        elemento3.classList.add('NoActivo');

                        console.log("1");

                        break;
                case '2':

                
                document.getElementById('triangulo').classList.add('pos2');
                document.getElementById('triangulo').classList.remove('pos1');
                document.getElementById('triangulo').classList.remove('pos3');

                document.getElementById('botonClinica').classList.remove("botonActivo");
                document.getElementById('botonFilosofia').classList.add("botonActivo");
                document.getElementById('botonEquipo').classList.remove("botonActivo");

                        elemento2.classList.add('activo');
                        elemento2.classList.remove('NoActivo');

                        elemento1.classList.remove('activo');
                        elemento3.classList.remove('activo');
                        elemento1.classList.add('NoActivo');
                        elemento3.classList.add('NoActivo');

                        console.log("2");
                        break;
                case '3':

                
                document.getElementById('triangulo').classList.add('pos3');
                document.getElementById('triangulo').classList.remove('pos1');
                document.getElementById('triangulo').classList.remove('pos2');

                        document.getElementById('botonClinica').classList.remove("botonActivo");
                        document.getElementById('botonFilosofia').classList.remove("botonActivo");
                        document.getElementById('botonEquipo').classList.add("botonActivo");

                        elemento3.classList.add('activo');
                        elemento3.classList.remove('NoActivo');

                        elemento1.classList.remove('activo');
                        elemento2.classList.remove('activo');
                        elemento1.classList.add('NoActivo');
                        elemento2.classList.add('NoActivo');

                        console.log("3");
                        break;

                default:
                        break;
        }
}

function MostrarMenu(){
        document.getElementById("barraNavegacion")
}